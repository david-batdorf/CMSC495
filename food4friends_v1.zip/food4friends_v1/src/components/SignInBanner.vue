<template>
  <div class="signin">
    <h1>Food 4 Friends</h1>
    <hr width="60%" />
    <img src="../assets/soup.jpg" />
    <p>A new way to give and receive food with people in your neighborhood.</p>

    <!-- BELOW IS TEST BUTTON FOR TESTING PURPOSES ONLY -->
    <div class="testButton" v-on:click="navigate()">
      <span class="icon"></span>
      <span class="buttonText">Sign In with Google</span>
    </div>

    <!-- BELOW IS GOOGLE OAUTH2 BUTTON CONNECTED TO API -->
    <!-- <g-signin-button :params="googleSignInParams" @success="onSignInSuccess" @error="onSignInError">
      <span class="icon"></span>
      <span class="buttonText">Sign In with Google</span>
    </g-signin-button>-->
  </div>
</template>

<script>
export default {
  name: "signinbanner",
  data() {
    return {
      /**
       * The Auth2 parameters, as seen on
       * https://developers.google.com/identity/sign-in/web/reference#gapiauth2initparams.
       * As the very least, a valid client_id must present.
       * @type {Object}
       */
      googleSignInParams: {
        client_id:
          "379813336107-0pa4h0hc6mjtu50rtegj7t1qtbsofmef.apps.googleusercontent.com"
      }
    };
  },
  methods: {
    navigate() {
      this.$router.push({ name: "home" });
    },
    onSignInSuccess(googleUser) {
      // `googleUser` is the GoogleUser object that represents the just-signed-in user.
      // See https://developers.google.com/identity/sign-in/web/reference#users
      const profile = googleUser.getBasicProfile(); // etc etc
      return profile; // placed to prevent no-unused-var error from eslint
    },
    onSignInError(error) {
      // prevent user to proceeding further in app
      return error; // placed to prevent no-unused-var error from eslint
    }
  }
};
</script>

<style scoped>
.signin {
  height: 500px;
  width: 300px;
  background-color: #fff;
  text-align: center;
  border-radius: 35px;
  padding: 20px 20px 20px 20px;
  margin: 200px 200px 0px;
}
.testButton {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 50px;
  background-color: #133d15;
  color: #fff;
  width: 280px;
  height: 80px;
}
.testButton:hover {
  cursor: pointer;
}
.g-signin-button {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 50px;
  background-color: #133d15;
  color: #fff;
  width: 280px;
  height: 80px;
}
.g-signin-button:hover {
  cursor: pointer;
}
span.icon {
  background: url("../assets/g-normal.png") transparent 5px 50% no-repeat;
  display: inline-block;
  vertical-align: middle;
  padding-top: 33px;
  width: 42px;
  height: 42px;
}
span.buttonText {
  display: inline-block;
  vertical-align: middle;
  padding-left: 35px;
  padding-right: 35px;
  font-size: 15px;
  font-weight: bold;
  font-family: "Roboto", sans-serif;
}


h3 {
  font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
  font-size: 30px;
}

p {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 20px;
  padding-bottom: 20px;
}

/**This can be deleted once button is added */
#G_SignIn {
  color: green;
}
</style>