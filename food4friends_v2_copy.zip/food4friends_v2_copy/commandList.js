var cmd;
var emailAddress;
var servingSize;
var timeWindow;
var locationID;
var page;
var orderID;
var userID;
var message;
var giversRating;

page = 'recieveFood';

//info for meetUp 
var recieverID = '1234';
orderID = 'gamerguy@dudemail.com1';
takersRating = '20 / 25';
///

//all info provided from other js script for postFood
emailAddress = 'gamerguy@dudemail.com';
servingSize = 1;
timeWindow = 120;
locationID = 1;
userID = 'K9AT';
message = 'hi there, i have tacos.';
giversRating = '39/50';
///end provided info for postFood


if (page == 'postFood') {
    orderID = emailAddress + servingSize;
    //orderid, locationid, giver, reciever, timestart, durationmins,message,giversrating,takersrating
    console.log("INSERT INTO QUEUE VALUES( '" + orderID + "', " + locationID + ", '" + userID + "', " + 'NULL' + ",now()," + "" + timeWindow + ",'" + message + "','" + giversRating + "'," + 'NULL' + ");");
    cmd = "INSERT INTO QUEUE VALUES( '" + orderID + "', " + locationID + ", '" + userID + "', " + 'NULL' + ",now()," + "" + timeWindow + ",'" + message + "','" + giversRating + "'," + 'NULL' + ");";
}
if (page == 'recieveFood') {
    cmd = 'SELECT * FROM QUEUE;';
}
if (page == 'meetUp') {
    console.log("UPDATE QUEUE SET RECIEVER='" + recieverID + "'," + "TAKERSRATING='" + takersRating + "'WHERE ORDERID='" + orderID + "';");

    cmd = "UPDATE QUEUE SET RECIEVER='" + recieverID + "'," + "TAKERSRATING='" + takersRating + "'WHERE ORDERID='" + orderID + "';";
}
    //cmd = "SELECT USERNAME FROM APPUSERS WHERE USERID='K9AT'";

module.exports = { cmd };
module.exports.selectAllQuery = function () {
	cmd = "SELECT * FROM QUEUE;";
	var result = require(db.js);
	console.log("---" + result);
};


//kiss\nuse FoodForFriends;\nSELECT USERNAME FROM APPUSERS WHERE USERID='K9At';