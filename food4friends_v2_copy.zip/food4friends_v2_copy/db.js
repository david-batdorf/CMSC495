﻿const mysqlssh = require('mysql-ssh');
const fs = require('fs');
var commands = require('./commandList');
var command = commands.cmd;
var output;
mysqlssh.connect(
    {
        host: '74.208.82.40',
        user: 'root',
        password: 'Cg3Z68wsy1'
    },
    {
        host: 'localhost',
        user: 'root',
        password: 'kiss',
        database: 'FoodForFriends'
    }
)
.then(client => {
    client.query(command, function (err, results, fields) {//command is query
        if (err) throw err//throws error if anything in the connection goes wrong
        console.log(results);//logs results of query
        output = JSON.stringify(results);//output = results of query
       // var i = output.lastIndexOf('"');//gets last "
       // output = output.slice(0, i);//slices off last " and everything after it
        //i = output.lastIndexOf('"');//gets new last "
       // output = output.slice(i+1, output.length);//slices new last " and everything before it
       // console.log(output);//prints output to console
        mysqlssh.close()//close sql ssh
    })
})
.catch(err => {
    console.log(err)
    })