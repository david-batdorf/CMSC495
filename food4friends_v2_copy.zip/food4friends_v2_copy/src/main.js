import Vue from 'vue'
import App from './App.vue'
import SignInBanner from './components/SignInBanner.vue'

//change the component below to test in plain page before customizing
import Test from './components/Test.vue'
import Router from 'vue-router'
import GSignInButton from 'vue-google-signin-button'

Vue.config.productionTip = false
Vue.use(GSignInButton)
Vue.use(Router)

const routes = [
  { path: '/', name: 'signIn', component: SignInBanner},
  { path: '/home', name: 'home', component: () => import('./pages/Role.vue')},
  { path: '/postFood', name: 'giver', component: () => import('./pages/PostFood.vue')},
  { path: '/postFood/confirmed', name: 'postConfirmed', component: () => import('./pages/Confirmation.vue')},
  { path: '/foodAvailable', name: 'receiver', component: () => import('./pages/FoodAvailable.vue')},
  { path: '/summary', name: 'transactionHistory', component: () => import('./pages/Summary.vue')},
  { path: '/test', name: 'test', component: Test}
];

const router = new Router({
  routes,
  mode: 'history'
});

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
