<template>
  <div class="foodForm">
    <div class="top">
      <span id="close" v-on:click="navigate('home')">X</span>
      <h2>Food Description</h2>

      <p>Add a little description as to what kind of food you are offering.</p>
      <div class="foodName">
        <input type="text" name="food" autocomplete="off" required />
        <label for="food" class="label-food">
          <span class="content-food">i.e. Chicken Soup</span>
        </label>
      </div>
    </div>

    <div class="row">
      <div class="column">
        <!-- inputs and labels -->
        <h3>How much food are you offering?</h3>
        <select class="serving">
          <option selected="selected" disabled="disabled">Number of Servings (#)</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
        </select>
        <h3>Food Availability Window</h3>
        <select class="available">
          <option selected="selected" disabled="disabled">How many hours (i.e. 2 hours)</option>
          <option value="1">1 hour</option>
          <option value="2">2 hours</option>
          <option value="3">3 hours</option>
        </select>
        <h3>Type Address</h3>
        <div class="address">
          <input type="text" name="addy" autocomplete="off" required />
          <label for="addy" class="label-addy">
            <span class="content-addy">Example: UMUC</span>
          </label>
        </div>
      </div>
      <div class="column">
        <div class="mapBox">
          <h3>Location</h3>
          <div class="map"></div>
        </div>
      </div>
    </div>
    <div class="post" v-on:click="navigate('postConfirmed')">
      <p>Post Food</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "foodForm",
  components: {},
  methods: {
    navigate(page) {
        this.$router.push({ name: page});
    }
  }
};
</script>

<style scoped>
.foodForm {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  width: 750px;
  height: 500px;
  border-radius: 30px;
  padding: 30px 30px;
}

.foodForm select {
  width: 100%;
}

.top {
  width: 100%;
}

#close {
  float: right;
}

#close:hover {
  cursor: pointer;
}

.foodName {
  width: 100%;
  position: relative;
  height: 50px;
  overflow: hidden;
}

.foodName input {
  width: 100%;
  height: 100%;
  color: #000;
  padding-top: 15px;
  border: none;
  outline: none;
}

.foodName label {
  position: absolute;
  bottom: 0px;
  left: 0%;
  width: 100%;
  height: 100%;
  pointer-events: none;
  border-bottom: 1px solid #8f8f8f;
}

.foodName label::after {
  content: " ";
  position: absolute;
  left: 0px;
  bottom: -2px;
  height: 100%;
  width: 100%;
  border-bottom: 2px solid #000;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.content-food {
  position: absolute;
  bottom: 5px;
  left: 0px;
  transition: all 0.3s ease;
}

.foodName input:focus + .label-food .content-food,
.foodName input:valid + .label-food .content-food {
  transform: translateY(-150%);
  font-size: 14px;
  color: #8f8f8f;
}

.foodName input:focus + .label-food::after,
.foodName input:valid + .label-food::after {
  transform: translateX(0%);
}

.address {
  width: 100%;
  position: relative;
  height: 50px;
  overflow: hidden;
}

.address input {
  width: 100%;
  height: 100%;
  color: #000;
  padding-top: 15px;
  border: none;
  outline: none;
}

.address label {
  position: absolute;
  bottom: 0px;
  left: 0%;
  width: 100%;
  height: 100%;
  pointer-events: none;
  border-bottom: 1px solid #8f8f8f;
}

.address label::after {
  content: " ";
  position: absolute;
  left: 0px;
  bottom: -2px;
  height: 100%;
  width: 100%;
  border-bottom: 2px solid #000;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.content-addy {
  position: absolute;
  bottom: 5px;
  left: 0px;
  transition: all 0.3s ease;
}

.address input:focus + .label-addy .content-addy,
.address input:valid + .label-addy .content-addy {
  transform: translateY(-150%);
  font-size: 14px;
  color: #8f8f8f;
}

.address input:focus + .label-addy::after,
.address input:valid + .label-addy::after {
  transform: translateX(0%);
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 50%;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 15px;
}

.mapBox {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.map {
  background-image: url("../assets/map.jpg");
  width: 300px;
  height: 250px;
}

.post {
  background-color: #4caf50;
  text-align: center;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.post:hover {
  cursor: pointer;
}

.post p {
  color: #fff;
  font-size: 12px;
}
</style>
