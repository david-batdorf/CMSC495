<template>
  <div class="transactions">
    
    <div class="row">
      <div class="column">
        <p>{{giver}}</p>
      </div>
      <div class="column">
        <p>{{receiver}}</p>
      </div>
      <div class="column">
        <p>{{transactionDescription}}</p>
      </div>
      <div class="column">
        <p>{{giverRating}}</p>
      </div>
      <div class="column">
        <p>{{receiverRating}}</p>
      </div>
      <hr width=75% />
    </div>
    
  </div>
</template>

<script>
export default {
  name: "transaction",
  props: ['giver', 'receiver', 'transactionDescription', 'giverRating', 'receiverRating'],
  components: {},
};
</script>

<style scoped>
.transactions {
  /* display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  position: fixed; */
  bottom: 0px;
  width: 100%;
  height: 550px;
  padding: 30px 30px;
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 20%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
