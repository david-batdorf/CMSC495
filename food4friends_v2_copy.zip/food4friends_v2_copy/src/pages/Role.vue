<template>
  <div class="role">
    <RoleChoice class="rc" />
  </div>
</template>

<script>
import RoleChoice from "../components/RoleChoice.vue";

export default {
  name: "role",
  components: {
    RoleChoice
  }
};
</script>

<style scoped>
.role {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  /* font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif; */
  
}

.rc {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
</style>
