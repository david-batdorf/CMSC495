<template>
  <div class="summary">
    <div class="name">
      <h2>Transaction Summary</h2>
    </div>
    <hr width=75% />
    <div class="row">
      <div class="column">
        <h3>Giver</h3>
      </div>
      <div class="column">
        <h3>Receiver</h3>
      </div>
      <div class="column">
        <h3>Transaction Description</h3>
      </div>
      <div class="column">
        <h3>Giver Rating</h3>
      </div>
      <div class="column">
        <h3>Receiver Rating</h3>
      </div>
    </div>
    <hr width=75%/>
    <trans-entry
    v-for="entry in trans"
    :key="entry.id"
    :giver="entry.giver"
    :receiver="entry.receiver"
    :transactionDescription="entry.transDesc"
    :giverRating="entry.gRate"
    :receiverRating="entry.rRate"
    ></trans-entry>
    

  </div>
</template>

<script>
import Transactions from '../components/Transactions.vue'

export default {
  name: "summary",

  data() {
      return {
      trans: [
          {id: '1', giver: 'David Batdorf', receiver: 'David Markowski', transDesc: "1 serving of Beef Tacos on 11/20/2019 at UMUC", gRate: '50/50', rRate: '50/50'},
          {id: '2', giver: 'David Markowski', receiver: 'Andrew Delgado', transDesc: '1 serving of Chicken Soup on 11/21/2019 at UMUC', gRate: '50/50', rRate: '50/50'},
          {id: '3', giver: 'David Markowski', receiver: 'Marcus Jones', transDesc: '1 serving of Guiness Stew on 11/22/2019 at UMUC', gRate: '50/50', rRate: '50/50'},

      ]}
  },

  components: {
      'trans-entry': Transactions
  }
};
</script>

<style scoped>
.summary {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  position: fixed;
  bottom: 0px;
  width: 100%;
  height: 550px;
  padding: 30px 30px;
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 20%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
