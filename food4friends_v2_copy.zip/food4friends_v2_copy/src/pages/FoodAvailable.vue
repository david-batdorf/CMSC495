<template>
  <div class="foodAvailable">
    <div class="name">
      <h2>Food Available near by</h2>
    </div>
    <hr width=75% />
    <div class="row">
      <div class="column">
        <h3>Giver</h3>
      </div>
      <div class="column">
        <h3>Food Type</h3>
      </div>
      <div class="column">
        <h3>Serving(s)</h3>
      </div>
      <div class="column">
        <h3>Availability</h3>
      </div>
      <div class="column">
        <h3>Location</h3>
      </div>
      <div class="column">
        <h3>Request</h3>
      </div>
    </div>
    <hr width=75%/>
    <Available
    v-for="entry in avail"
    :key="entry.id"
    :giver="entry.giver"
    :foodType="entry.foodType"
    :servings="entry.servings"
    :availability="entry.availability"
    :location="entry.location"
    ></available>
    

  </div>
</template>

<script>
import Available from '../components/Available.vue'

export default {
  name: "foodAvailable",

  data() {
      return {
      avail: [
          {id: '1', giver: 'Andrew Delgado', foodType: 'Chilli', servings: "1", availability: '5:00', location: 'UMUC'},
          {id: '2', giver: 'Marcus Jones', foodType: 'Turkey Dinner', servings: '1', availability: '4:30', location: 'UMUC'},
          {id: '3', giver: 'David Batdorf', foodType: 'Spaghetti', servings: '1', availability: '4:00', location: 'UMUC'},

      ]}
  },

  components: {
      Available
  }
};
</script>

<style scoped>
.foodAvailable {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  position: fixed;
  bottom: 0px;
  width: 100%;
  height: 550px;
  padding: 30px 30px;
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 16%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
