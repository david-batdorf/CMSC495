
module.exports = {
    // options...
    devServer: {
        disableHostCheck: true
    }
}
