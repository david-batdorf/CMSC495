//object that holds data for a user
import dbConnectService from '../js/dbConnectService';
//user variables
var userProfile;
var firstName = "";
var lastName = "";
var emailAddress = "";
var imageUrl = "";
//rating variable for future release update
var rating = 0;
var location = "";
var role = "";


class friend {
    
    // constructor used from the Google OAuth function
    constructor(profile) {
        userProfile = profile;
        console.log("Friend Info:" + userProfile);
    }

    getProfile() {
        return userProfile;
    }

    
    
}

export default friend;
