<template>
  <!-- <div class="muContainer"> -->
  <div class="meetUp">
    <div class="close" v-on:click="$router.go(-1);">X</div>
    <img id="receiverImage" />
    <p>{{ recName }} wants to meet up to receive {{ food }}</p>
    <div class="row">
      <div class="column">
        <div class="meetUpButton" v-on:click="completeFoodItem()">
          <p>Meet Up</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import dbConnectService from "../js/dbConnectService";
export default {
  name: "MeetUp",

  data() {
    return {
      recImgUrl: String,
      recName: String,
      food: String,
      orderId: String
    };
  },

  components: {},

  mounted() {
    if (localStorage.recImgUrl) {
      this.recImgUrl = localStorage.recImgUrl;
      // set the url to the image to the stored URL for Google
      document.getElementById("receiverImage").src = this.recImgUrl;
    }
    if (localStorage.recName) {
      this.recName = localStorage.recName;
    }
    if (localStorage.food) {
      this.food = localStorage.food;
    }
    if (localStorage.orderId) {
      this.orderId = localStorage.orderId;
    }
  },

  methods: {
    async completeFoodItem() {
      await dbConnectService.completeFoodItem(this.orderId);
      // go back one page from history
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped>
.meetUp {
  width: 520px;
  height: 300px;
  background-color: #fff;
  border-radius: 25px;
  position: relative;
  text-align: center;
  top: 50%;
  left: 50%;
  margin-top: -260px;
  margin-left: -150px;
}

.close {
  position: absolute;
  right: 15px;
  top: 10px;
}

.close:hover {
  cursor: pointer;
}

#receiverImage {
  border-radius: 50%;
  width: 75px;
  height: 75px;
  text-align: center;
  margin-top: 10%;
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 50%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}

.meetUpButton {
  background-color: #4caf50;
  text-align: center;
  display: inline-block;
  vertical-align: middle;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.meetUpButton:hover {
  cursor: pointer;
}

.meetUpButton p {
  color: #fff;
  font-size: 14px;
  margin-top: 10%;
}

.declineButton {
  background-color: #ff0000;
  text-align: center;
  display: inline-block;
  vertical-align: middle;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.declineButton:hover {
  cursor: pointer;
}

.declineButton p {
  color: #fff;
  font-size: 14px;
  margin-top: 10%;
}
</style>
