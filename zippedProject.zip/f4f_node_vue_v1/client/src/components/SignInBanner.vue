<template>
  <div class="signin">
    <h1>Food 4 Friends</h1>
    <hr width="60%" />
    <img src="../assets/soup.jpg" />
    <p>A new way to give and receive food with people in your neighborhood.</p>

    <!-- BELOW IS GOOGLE OAUTH2 BUTTON CONNECTED TO API -->
    <g-signin-button :params="googleSignInParams" @success="onSignInSuccess" @error="onSignInError">
      <span class="icon"></span>
      <span class="buttonText">Sign In with Google</span>
    </g-signin-button>
  </div>
</template>

<script>
import dbConnectService from "../js/dbConnectService";
import friend from "../js/friend";

export default {
  name: "signinbanner",
  data() {
    return {
      // data associated with component
      gProfile: Object,
      userInfo: [],
      userId: String,
      email: String,
      firstName: String,
      lastName: String,
      imgUrl: String,
      error: "",

      /**
       * The Auth2 parameters, as seen on
       * https://developers.google.com/identity/sign-in/web/reference#gapiauth2initparams.
       * As the very least, a valid client_id must present.
       * @type {Object}
       */
      googleSignInParams: {
        client_id:
          "379813336107-0pa4h0hc6mjtu50rtegj7t1qtbsofmef.apps.googleusercontent.com"
      }
    };
  },

mounted() {
    if(localStorage.firstName) {
      this.firstName = localStorage.firstName;
    }
    if(localStorage.lastName) {
      this.lastName = localStorage.lastName;
    }
    if(localStorage.email) {
      this.email = localStorage.email;
    }
    if(localStorage.imgUrl) {
      this.imgUrl = localStorage.imgUrl;
    }
    if(localStorage.userId) {
      this.userId = localStorage.userId;
    }
  },

  methods: {
    /** this is a test method for testing parameter passing */
    navigate() {
      dbConnectService.getUser(this.email);
    },

    async onSignInSuccess(googleUser) {
      // `googleUser` is the GoogleUser object that represents the just-signed-in user.
      // See https://developers.google.com/identity/sign-in/web/reference#users
      var gProfile = googleUser.getBasicProfile(); // pull profile to parse necessary information
      
      localStorage.email = gProfile.getEmail();      
      
      this.userInfo = await dbConnectService.getUser(localStorage.email);
      
      if (Array.isArray(this.userInfo) && this.userInfo.length) {
        localStorage.firstName = this.userInfo[0].FIRSTNAME;
        localStorage.lastName = this.userInfo[0].LASTNAME;
        localStorage.imgUrl = this.userInfo[0].IMGURL;
        localStorage.userId = this.userInfo[0].USERID;
      } else {
        localStorage.firstName = gProfile.getGivenName();
        localStorage.lastName = gProfile.getFamilyName();
        localStorage.imgUrl = gProfile.getImageUrl();
        var userId = gProfile.getEmail(); 
        localStorage.userId = userId;
        dbConnectService.insertUser(
          localStorage.userId, 
          localStorage.firstName, 
          localStorage.lastName, 
          localStorage.email, 
          localStorage.imgUrl
        );
      }
      this.$router.push({ name: "home" });

      /* this.friend = new friend(userInfo); */
    },
    onSignInError(error) {
      // prevent user to proceeding further in app
      return error; // placed to prevent no-unused-var error from eslint
    },
    
  },
};
</script>

<style scoped>
.signin {
  height: 500px;
  width: 300px;
  background-color: #fff;
  text-align: center;
  border-radius: 35px;
  padding: 20px 20px 20px 20px;
  margin: 200px 200px 0px;
}
.testButton {
  display: table;
  padding: 4px 8px;
  border-radius: 50px;
  background-color: #4caf50;
  color: #fff;
  align-content: center;
  width: 280px;
  height: 80px;
}
.testButton:hover {
  cursor: pointer;
}
.g-signin-button {
  display: table;
  padding: 4px 8px;
  border-radius: 50px;
  background-color: #4caf50;
  color: #fff;
  align-content: center;
  width: 280px;
  height: 80px;
}
.g-signin-button:hover {
  cursor: pointer;
}
span.icon {
  display: inline-block;
  margin-top: 17px;
  margin-left: 7px;
  width: 42px;
  height: 42px;
  background: url("../assets/g-normal.png") no-repeat;
  background-color: #fff;
}
span.buttonText {
  display: table-cell;
  vertical-align: middle;
  padding-left: 35px;
  padding-right: 35px;
  font-size: 15px;
  font-weight: bold;
  font-family: "Roboto", sans-serif;
}

h3 {
  font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
  font-size: 30px;
}

p {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 20px;
  padding-bottom: 20px;
}

/**This can be deleted once button is added */
#G_SignIn {
  color: green;
}
</style>