<template>
  <div class="rolechoice">
    <h1>
      <strong>Choose a role</strong>
    </h1>
    <div class="roleButton" v-on:click="navigate('giver')">
      <p>Giver</p>
    </div>
    <span id="space"></span>
    <div class="roleButton" v-on:click="navigate('receiver')">
      <p>Receiver</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "roleChoice",

  methods: {
    navigate(role) {
      this.$router.push({ name: role });
    }
  }
};
</script>

<style scoped>
.rolechoice {
  width: 500px;
  height: 170px;
  text-align: center;
}

h1 {
  color: #fff;
  padding-bottom: 10%;
}

.roleButton {
  background-color: #4caf50;
  text-align: center;
  display: inline-block;
  vertical-align: middle;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.roleButton:hover {
  cursor: pointer;
}

.roleButton p {
  color: #fff;
  font-size: 12px;
  padding-top: 4%;
}

#space {
    width: 60px;
    display: inline-block;
}
</style>