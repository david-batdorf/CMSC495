<template>
  <div class="foodAvailable">
    <div class="name">
      <h2>Food Available near by</h2>
    </div>
    <hr width=75% />
    <div class="faBox" v-if="avail.length < 1">
      <h3>No transations at the moment</h3>
    </div>
  <div class="faBox" v-if="avail.length > 0">
    <div class="row">
      <div class="column">
        <h3>Giver</h3>
      </div>
      <div class="column">
        <h3>Food Type</h3>
      </div>
      <div class="column">
        <h3>Serving(s)</h3>
      </div>
      <div class="column">
        <h3>Availability</h3>
      </div>
      <div class="column">
        <h3>Location</h3>
      </div>
      <div class="column">
        <h3>Request</h3>
      </div>
    </div>
    <hr width=75%/>
    <Available
    v-for="entry in avail"
    :key="entry.ORDERID"
    :orderId="entry.ORDERID"
    :giver="entry.GIVER"
    :foodType="entry.MESSAGE"
    :servings="entry.SERVINGS"
    :availability="entry.AVAILABILITY"
    :location="entry.PLACENAME"
    ></available>
    

  </div>
  </div>
</template>

<script>
import Available from '../components/Available.vue'
import dbConnectService from '../js/dbConnectService'

export default {
  name: "foodAvailable",

  data() {
      return {
      avail: []
      }
  },

  components: {
      Available
  },
//local method to get available food based on database querry
  async created() {
    try {
      this.avail = await dbConnectService.getAvailableFood(
        localStorage.userId
      );
    } catch (err) {
      this.error = err.message;      
    }
  }
};
</script>

<style scoped>
.foodAvailable {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  position: fixed;
  bottom: 0px;
  width: 100%;
  height: 550px;
  padding: 30px 30px;
  
  overflow: auto;
}

.faBox {
  width: 100%;
  text-align: center;
  overflow: auto;
}

.row {
  width: 100%;
  background-color: #fff;
  position: sticky;
  top: 0px;
}

.column {
  float: left;
  width: 16%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
