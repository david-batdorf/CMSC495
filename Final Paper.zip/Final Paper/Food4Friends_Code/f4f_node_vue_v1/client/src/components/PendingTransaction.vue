<template>
  <!-- <div class="transactions"> -->
    <div class="ptRow">
      <div class="column">
        <p>{{ giver }}</p>
      </div>
      <div class="column">
        <p>{{ receiver }}</p>
      </div>
      <div class="column">
        <p>{{ transactionDescription }}</p>
      </div>
      <div class="column">
        <p>{{ availability }} minutes remaining</p>
      </div>
      <div class="column">
        <p>{{ location }}</p>
      </div>
      <div class="column">
        <div class="cancelButton"  v-on:click="cancelOffer()">
          <p>Cancel</p>
        </div>
      </div>
    </div>
  <!-- </div> -->
</template>

<script>
import dbConnectService from '../js/dbConnectService'
export default {
  name: "transaction",
  props: [
    "orderId",
    "giver",
    "receiver",
    "transactionDescription",
    "availability",
    "location"
  ],
  
  components: {},

  //page methods
  methods: {
      //when an offer is canceled the database is contacted and 
      //the item is removed from the database
      cancelOffer() {
          dbConnectService.cancelPendingOffer(this.orderId);
          //console.log(this.orderId);
          this.$emit("deleteThisItem", this.orderId);

      }
  }
};
</script>

<style scoped>
.transactions {
  /* display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  position: fixed; */
  bottom: 0px;
  width: 100%;
  height: 10%;
}

.ptRow {
  width: 100%;
}

.column {
  float: left;
  width: 16%;
  text-align: center;
}

.ptRow:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}

.cancelButton {
  background-color: #ff0000;
  text-align: center;
  display: inline-block;
  vertical-align: middle;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.cancelButton:hover {
  cursor: pointer;
}

.cancelButton p {
  color: #000;
  font-size: 12px;
  padding-top: 4%;
}
</style>
