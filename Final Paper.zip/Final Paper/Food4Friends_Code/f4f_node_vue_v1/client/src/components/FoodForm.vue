<template>
  <form class="foodForm" @submit.prevent="checkOffering" >
    <div class="top">
      <span id="close" v-on:click="$router.go(-1)">X</span>
      <h2>Food Description</h2>
      <p v-if="errors.length" class="error">
        <b>Please correct the following error(s):</b>
        <ul>
          <li v-for="(error, index) in errors" :key="index">{{ error }}</li>
        </ul>
      </p>
      <p>Add a little description as to what kind of food you are offering.</p>
      <div class="foodName">
        <input type="text" name="food" v-model="foodName" autocomplete="off" required />
        <label for="food" class="label-food">
          <span class="content-food">i.e. Chicken Soup</span>
        </label>
      </div>
    </div>

    <div class="row">
      <div class="column">
        <!-- inputs and labels -->
        <h3>How much food are you offering?</h3>
        <select class="serving" v-model="serving">
          <option selected="selected" disabled="disabled">Number of Servings (#)</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
        </select>
        <h3>Food Availability Window</h3>
        <select class="available" v-model="available">
          <option selected="selected" disabled="disabled">How many hours (i.e. 2 hours)</option>
          <option value="1">1 hour</option>
          <option value="2">2 hours</option>
          <option value="3">3 hours</option>
        </select>
        <h3>Meet Up Location</h3>
        <div class="address">
          <input
            type="text"
            :disabled="true"
            v-model="address"
            name="addy"
            autocomplete="off"
            required
          />
          <label for="addy" class="label-addy">
            <span class="content-addy">UMGC Campus Main Enterance</span>
          </label>
        </div>
      </div>
      <div class="column">
        <div class="mapBox">
          <h3>Location</h3>
          <div class="map"></div>
        </div>
      </div>
    </div>
    <div class="post" v-on:click="checkOffering">
      <p>Post Food</p>
    </div>
  </form>
</template>

<script>
import dbConnectService from "../js/dbConnectService";
export default {
  name: "foodForm",
  components: {},
  data() {
    return {
      foodName: null,
      serving: null,
      available: null,
      email: "",
      userId: "",
      address: "",
      errors: [],
    };
  },
  //on iniital page load, the page pulls user email and ID from browser local storage.
  mounted() {
    if (localStorage.email) {
      this.email = localStorage.email;
    }
    if (localStorage.userId) {
      this.userId = localStorage.userId;
    }
  },
  //page methods
  methods: {
    async navigate(page) {
      // check for data required from form before submitting
      console.log("Started to Navigate");
      //this.checkform();
      var today = new Date();
      var time =
      today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
      // create and_or store vaules to be inserted into database
      var emailId = this.email + time;
      // userId is stored per the mounted lifecycle
      // get first char of available string
      var duration = this.available.charAt(0);
      duration = parseInt(duration);
      duration *= 60; // convert to minutes
      // this.foodName will pull from form
      // this.servings will pull from form
      //database connection to post the food offering into the database
      await dbConnectService.offerFood(
        emailId,
        this.userId,
        duration,
        this.foodName,
        this.serving
      );
      //sends the user to the designated page.
      this.$router.push({ name: page });
    },

    //method designed to check for user input into all fields and only progress to the posting if all fields are completed
    //unfilled fields will display an error
    checkOffering: function() {
      console.log("checking form");
      if(this.foodName && this.serving && this.available && this.address) return true;
      this.errors = [];
      if(!this.foodName) this.errors.push("Food description required");
      else if(!this.serving) this.errors.push("Serving size is required");
      else if(!this.available) this.errors.push("Available time is required");
      /* else if(!this.address) this.errors.push("Address is required"); future update */
      //only if all fields are completed post the food item
      else this.navigate('postConfirmed');
    }
  }
};
</script>

<style scoped>
.foodForm {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  width: 750px;
  min-height: 500px;
  border-radius: 30px;
  padding: 30px 30px;
  flex: 1;
}

.error{
  color: red;
}

.foodForm select {
  width: 100%;
}

.top {
  width: 100%;
}

#close {
  float: right;
}

#close:hover {
  cursor: pointer;
}

.foodName {
  width: 100%;
  position: relative;
  height: 50px;
  overflow: hidden;
}

.foodName input {
  width: 100%;
  height: 100%;
  color: #000;
  padding-top: 15px;
  border: none;
  outline: none;
}

.foodName label {
  position: absolute;
  bottom: 0px;
  left: 0%;
  width: 100%;
  height: 100%;
  pointer-events: none;
  border-bottom: 1px solid #8f8f8f;
}

.foodName label::after {
  content: " ";
  position: absolute;
  left: 0px;
  bottom: -2px;
  height: 100%;
  width: 100%;
  border-bottom: 2px solid #000;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.content-food {
  position: absolute;
  bottom: 5px;
  left: 0px;
  transition: all 0.3s ease;
}

.foodName input:focus + .label-food .content-food,
.foodName input:valid + .label-food .content-food {
  transform: translateY(-150%);
  font-size: 14px;
  color: #8f8f8f;
}

.foodName input:focus + .label-food::after,
.foodName input:valid + .label-food::after {
  transform: translateX(0%);
}

.address {
  width: 100%;
  position: relative;
  height: 50px;
  overflow: hidden;
}

.address input {
  width: 100%;
  height: 100%;
  color: #000;
  padding-top: 15px;
  border: none;
  outline: none;
}

.address label {
  position: absolute;
  bottom: 0px;
  left: 0%;
  width: 100%;
  height: 100%;
  pointer-events: none;
  border-bottom: 1px solid #8f8f8f;
}

.address label::after {
  content: " ";
  position: absolute;
  left: 0px;
  bottom: -2px;
  height: 100%;
  width: 100%;
  border-bottom: 2px solid #000;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
}

.content-addy {
  position: absolute;
  bottom: 5px;
  left: 0px;
  transition: all 0.3s ease;
}

.address input:focus + .label-addy .content-addy,
.address input:valid + .label-addy .content-addy {
  transform: translateY(-150%);
  font-size: 14px;
  color: #8f8f8f;
}

.address input:focus + .label-addy::after,
.address input:valid + .label-addy::after {
  transform: translateX(0%);
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 50%;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 15px;
}

.mapBox {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.map {
  background-image: url("../assets/map.jpg");
  width: 300px;
  height: 250px;
}

.post {
  background-color: #4caf50;
  text-align: center;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.post:hover {
  cursor: pointer;
}

.post p {
  color: #fff;
  font-size: 12px;
}
</style>
