<template>
  <div class="ptBox">
    <h1>Pending Transactions</h1>
    <hr width="90%" />
    <div class="ptBox" v-if="transactions.length < 1">
      <h3>No transactions at the moment</h3>
    </div>
    <div class="ptBox" v-if="transactions.length > 0">
      <div class="row">
        <div class="column">
          <h3>Giver</h3>
        </div>
        <div class="column">
          <h3>Receiver</h3>
        </div>
        <div class="column">
          <h3>Transaction Description</h3>
        </div>
        <div class="column">
          <h3>Availability</h3>
        </div>
        <div class="column">
          <h3>Location</h3>
        </div>
      </div>
      <PendingTransaction 
      v-for="item in transactions"
      :key="item.ORDERID"
      :orderId="item.ORDERID"
      :giver="item.GIVER"
      :receiver="item.RECEIVER"
      :transactionDescription="item.TRANSACTIONDESCRIPTION"
      :availability="item.AVAILABILITY"
      :location="item.PLACENAME"
      v-on:deleteThisItem="deleteThisItem(orderId)"
      ></PendingTransaction>
    </div>
  </div>
</template>

<script>
import PendingTransaction from "../components/PendingTransaction";
import dbConnectService from "../js/dbConnectService";

export default {
  name: "",

  data() {
    return {
      userId: String,
      transactions: [],
      completed: 'false',
      error: ""
    };
  },

  //on page load save the local user ID to page variable
  mounted() {
    if (localStorage.userId) {
      this.userId = localStorage.userId;
    }
  },

  components: {
    PendingTransaction
  },

  async created() {
    try {
      //holding code to wait for database connection and saving it to local variable
      this.transactions = await dbConnectService.getTransactions(
        localStorage.userId,
        this.completed
      );
    } catch (err) {
      //saving error to variable
      this.error = err.message;
    }
    this.checkForPending();
  },

methods: {
    //when a item is deleted from database refresh page to ensure correct displayed 
    deleteThisItem(e) {
      window.location.reload(true);
    },

    //method that checks for pending transactions
    async checkForPending() {
      try {
        //waiting for database call and saving result to a local variable
        this.transactions = await dbConnectService.getTransactions(
          localStorage.userId,
          this.completed
        );
        //reseting variable for notification of transaction
        localStorage.notify = false;
        if (Array.isArray(this.transactions) && this.transactions.length) {
          this.transactions.forEach(function(item) {
            //checking for a pending transaction where the current user isnt NOT the receiver.
            if ((item.RECEIVER != null) && item.RECEIVER != (localStorage.firstName + " " + localStorage.lastName)) {
              //reloading page the first time a notification is found and setting local store variable
              if(localStorage.notify == false){
                localStorage.notify = true;
                window.location.reload(true);
              }
              //else only setting the variable
              else{
              localStorage.notify = true;

              }
              //storing the items data to local storage.
              localStorage.recImgUrl = item.IMGURL;
              localStorage.recName = item.RECEIVER;
              localStorage.food = item.MESSAGE;
              localStorage.orderId = item.ORDERID;
            }
          });
        }
      } catch (err) {
        this.error = err.message;
      }
    }
  }
};
</script>


<style scoped>
.ptBox {
  width: 100%;
  text-align: center;
  overflow: auto;
}

.row {
  width: 100%;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}

.column {
  float: left;
  width: 16%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
