<template>
  <div class="postConfirm">
      <h3>Food Posting Successful!</h3>
    <div class="homeButton" v-on:click="navigate('home')">
      <p>Home</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "postConfirm",

  //method for post confirmation popup.  
  methods: {
    navigate(page) {
      //routes the user to the page sent to the method
      this.$router.push({ name: page });
    }
  }
};
</script>

<style scoped>
.postConfirm {
  display: flex;
  flex-direction: column;
  justify-content: column;
  align-items: center;
  background-color: #fff;
  margin: auto;
  border-radius: 30px;
  width: 600px;
  height: 200px;
}

h3 {
    margin: auto;
}
.homeButton {
    display: flex;
  background-color: #4caf50;
  text-align: center;
  margin: auto;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.homeButton:hover {
  cursor: pointer;
}

.homeButton p {
  color: #fff;
  margin: auto;
  font-size: 12px;
}
</style>