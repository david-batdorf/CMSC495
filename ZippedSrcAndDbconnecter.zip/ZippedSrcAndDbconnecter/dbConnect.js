const express = require('express');
const mysqlssh = require('mysql-ssh');

const router = express.Router();

var output;

// Get App User on login
/* IMPLEMENTED */
router.get('/user/:userId', async (req, res) => {
    try{
        var userId = req.params.userId;
        var query = "SELECT * FROM APPUSERS WHERE USERID = '" + userId + "';";
        //console.log(query);
        var result = await connectAndQuery(query);
        //res.send(output);
        //console.log("Outside: " + output);
        setTimeout(function () {
            res.send(output);
            //console.log("Inside Timeout: " + output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

// inserting a new user into database
/* IMPLEMENTED */
router.post('/user', (req, res) => {
    try{
        var userId = req.body.userId;
        var fName = req.body.fName;
        var lName = req.body.lName;
        var email = req.body.email;
        var imgUrl = req.body.imgUrl;
        var query = "INSERT INTO APPUSERS(USERID,FIRSTNAME,LASTNAME,EMAIL,IMGURL)" +
            "VALUES('" + userId + "','" + fName + "','" + lName + "','" + email + "','" + imgUrl + "');";
        connectAndQuery(query);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }   
})

// deletes all the users entries in the queue. ALWAYS run this prior to /offerFood
router.get('/prepOffer', (req, res) => {
    try{
        var query = "DELETE FROM QUEUE WHERE GIVER = " + "'" + userId + "';";
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

// GIVER/FOOD DESCRIPTION/ OFFER FOOD PAGE
/* IMPLEMENTED */
router.post('/offerFood', (req, res) => {
    try{
        var emailId = req.body.emailId;
        var userId = req.body.userId;
        var duration = req.body.duration;
        var foodName = req.body.foodName;
        var servings = req.body.servings;
        var query = "INSERT INTO QUEUE(ORDERID,LOCATIONID,GIVER,RECEIVER,TIMESTART,DURATIONMINS,MESSAGE,GIVERSRATING,TAKERSRATING,SERVINGS,COMPLETED)" +
            "VALUES('" + emailId + "',1,'" + userId + "',NULL,NOW(),'" + duration + "','" + foodName + "',NULL,NULL,'" + servings + "',false);";
        //console.log("OfferFood: " + query);
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

//pending transactions page
//shows all the pending transactions
/* IMPLEMENTED */
router.get('/transactions', (req, res) => {
    try{
        var userId = req.query.userId;
        var completed = req.query.completed;
        //console.log(completed);
        var query = "SELECT Q.ORDERID, CONCAT(G.FIRSTNAME, ' ', G.LASTNAME) AS \"GIVER\", CONCAT(R.FIRSTNAME, ' ', R.LASTNAME) AS \"RECEIVER\", " +
        "CONCAT(Q.SERVINGS, ' servings of ', Q.MESSAGE) AS \"TRANSACTIONDESCRIPTION\", Q.MESSAGE, TIMESTAMPDIFF(MINUTE,NOW(),DATE_ADD(Q.TIMESTART, INTERVAL Q.DURATIONMINS MINUTE)) " + 
        "AS \"AVAILABILITY\", L.PLACENAME, Q.GIVERSRATING, Q.TAKERSRATING, R.IMGURL FROM `QUEUE` Q JOIN LOCATIONS L ON " +
        "Q.LOCATIONID = L.LOCATIONID LEFT JOIN `APPUSERS` G ON Q.GIVER = G.USERID LEFT JOIN `APPUSERS` R ON Q.RECEIVER = R.USERID WHERE (Q.GIVER = '"
        + userId + "' OR Q.RECEIVER = '"+userId+"') AND DATE_ADD(Q.TIMESTART, INTERVAL Q.DURATIONMINS MINUTE) > NOW() AND COMPLETED = "+completed+";";
        //console.log(query);
        var result = connectAndQuery(query);
        //console.log("Pending Transactions: "+query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

//cancel giving food
/* IMPLEMENTED */
router.delete('/cancelDropOff/:orderId', (req, res) => {
    try{
        var orderId = req.params.orderId;
        var query = "DELETE FROM QUEUE WHERE ORDERID='" + orderId + "';";
        //console.log(query);
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

// deletes all the users accepted food entries in the queue. ALWAYS run this prior to /recieveFood
router.get('/prepRecieve', (req, res) => {
    try{
        var query = "UPDATE QUEUE SET RECIEVER='' WHERE RECIEVER='" + userId + "';";
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

//recieve food button
/* IMPLEMENTED */
router.post('/receiveFood', (req, res) => {
    try{
        var orderId = req.body.orderId;
        var userId = req.body.userId;
        var query = "UPDATE QUEUE SET RECEIVER='" + userId + "' WHERE ORDERID ='" + orderId + "';";
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

//cancel recieving food
/* IMPLEMENTED */
router.post('/cancelReceiving', (req, res) => {
    try{
        var orderId = req.body.orderId;
        //console.log(orderId);
        var query = "UPDATE QUEUE SET RECEIVER = null WHERE ORDERID ='" + orderId + "';";
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});

//FOOD AVAILABLE PAGE
/* IMPLEMENTED */
router.get('/foodAvailable/:userId', (req, res) => {
    try{
        var userId = req.params.userId;
        var query = "SELECT Q.ORDERID, CONCAT(G.FIRSTNAME, ' ', G.LASTNAME) AS \"GIVER\", Q.MESSAGE, Q.SERVINGS, TIMESTAMPDIFF(MINUTE,NOW(),DATE_ADD(Q.TIMESTART, INTERVAL Q.DURATIONMINS MINUTE)) AS \"AVAILABILITY\", L.PLACENAME FROM " +
        "`QUEUE` Q JOIN LOCATIONS L ON Q.LOCATIONID = L.LOCATIONID LEFT JOIN `APPUSERS` G ON Q.GIVER = G.USERID WHERE (Q.GIVER NOT LIKE '" + userId + 
        "' AND Q.RECEIVER IS NULL) AND DATE_ADD(TIMESTART, INTERVAL DURATIONMINS MINUTE) > NOW();";
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});


// completed the food offer request-time to complete meetup
/* IMPLEMENTED */
router.post('/completeMeetUp', (req, res) => {
    try{
        var orderId = req.body.orderId;
        //console.log(orderId);
        var query = "UPDATE QUEUE SET COMPLETED = true WHERE ORDERID ='" + orderId + "';";
        var result = connectAndQuery(query);
        setTimeout(function () {
            res.send(output);
        }, 3000);
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
});



async function connectAndQuery(command) {
    try{
        mysqlssh.connect(
            {
                host: '74.208.82.40',
                user: 'root',
                password: 'Cg3Z68wsy1'
            },
            {
                host: 'localhost',
                user: 'root',
                password: 'kiss',
                database: 'FoodForFriends'
            }
        )
            .then(client => {
                client.query(command, function (err, results) {//command is query
                    if (err) console.log("Error: " + Error);
                    output = JSON.stringify(results);
                    //console.log("ConnectAndQuery");
                    mysqlssh.close();//close sql ssh
                    return output;
                })
            })
            .catch(err => {
	console.log("Error: " + Error);
            })
    }catch(Error){
        // WE can trow certian errors or all or even do a recconnect or relogin
	console.log("Error: " + Error);
    }
}

module.exports = router;
