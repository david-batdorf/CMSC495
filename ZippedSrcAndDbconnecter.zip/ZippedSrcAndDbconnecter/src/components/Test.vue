<template>
  <div class="test">
    <RoleChoice />
  </div>
</template>

<script>
/* import RoleChoice from "RoleChoice.vue"; */

export default {
  name: "test",

  components: {
    /* RoleChoice */
  }
};
</script>

<style scoped>



</style>
