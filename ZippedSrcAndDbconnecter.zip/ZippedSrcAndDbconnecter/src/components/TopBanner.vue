<template>
  <div class="top">
    <h1>Food 4 Friends</h1>
    <p v-on:click="navigate('home')">
      <strong>Home</strong>
    </p>
    <p v-on:click="navigate('transactionHistory')">
      <strong>Transaction History</strong>
    </p>
    <p v-on:click="logOut()">
      <strong>Log Out</strong>
    </p><span class="profileImage">
      <img id="profileImageUrl" />      
      <i class="material-icons" id="bell" v-if="bellCheck()" v-on:click="navigate('meetUp')">Active Request!</i>
    </span>
  </div>
</template>
<script>
export default {
  name: "topbanner",
  // data dependant

  data() {
    return {
      imgUrl: String,
      timer: ''
      
    };
  },
  created() {
    // checks the notification bell status upon creation
    this.bellCheck();
    // run bellCheck every 10 seconds looking for a change in notify status
    this.timer = setInterval(() => this.bellCheck(), 60000);
  },
  mounted() {
    if (localStorage.imgUrl) {
      this.imgUrl = localStorage.imgUrl;
      // set the url to the image to the stored URL for Google
      document.getElementById("profileImageUrl").src = this.imgUrl;
    }
  },

  methods: {
    navigate(page) {
      this.$router.push({ name: page });
    },

    logOut() {
      localStorage.clear();
      this.navigate('signIn');
    },
    bellCheck() {
      if(localStorage.notify == 'true') {
        return true;
      } else {
        return false;
      }
    }
  }
};
</script>

<style scoped>
.top {
  background-color: #fff;
  opacity: 70%;
  height: 115px;
  width: 100%;
  display: table;
  /* padding-top: 15px; */
}

.top h1 {
  text-align: left;
  font-size: 40px;
  margin-left: 40px;
  display: inline-table;
  vertical-align: middle;
}

.top p {
  font-size: 20px;
  color: #000;
  display: inline-table;
  /* margin-top: 30px; */
  vertical-align: middle;
  padding-left: 50px;
}

.top p:hover {
  cursor: pointer;
}

.profileImage {
  background-repeat: no-repeat;
  float: right;
  vertical-align: middle;
  margin-top: 25px;
  margin-right: 5px;
}

#profileImageUrl {
  border-radius: 50%;
  width: 75px;
  height: 75px;
}
#bell {
  color: red;
  vertical-align: top;
  font-size: 50px;
  /* margin-right: 1%;*/
  margin-top: 10%;
}

#bell:hover {
  cursor: pointer;
}
</style>