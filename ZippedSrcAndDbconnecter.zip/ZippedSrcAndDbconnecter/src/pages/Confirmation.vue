<template>
  <div class="postFood">
    <Confirmation style="margin-top:15%" />
  </div>
</template>

<script>
import Confirmation from "../components/PostConfirmation.vue";

export default {
  name: "postFood",
  components: {
    Confirmation
  }
};
</script>

<style scoped>
.postFood {
  display: flex;
  flex-direction: column;
  justify-content: column;
  align-items: center;
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  /* font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif; */
}

</style>
