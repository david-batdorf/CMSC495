<template>
  <div class="summary">
    <div class="name">
      <h2>Transaction Summary</h2>
    </div>
    <hr width=75% />
    <div class="row">
      <div class="column">
        <h3>Giver</h3>
      </div>
      <div class="column">
        <h3>Receiver</h3>
      </div>
      <div class="column">
        <h3>Transaction Description</h3>
      </div>
      <div class="column">
        <h3>Giver Rating</h3>
      </div>
      <div class="column">
        <h3>Receiver Rating</h3>
      </div>
    </div>
    <hr width=75%/>
    <trans-entry
    v-for="entry in trans"
    :key="entry.ORDERID"
    :giver="entry.GIVER"
    :receiver="entry.RECEIVER"
    :transactionDescription="entry.TRANSACTIONDESCRIPTION"
    :giverRating="entry.gRate"
    :receiverRating="entry.rRate"
    ></trans-entry>
    

  </div>
</template>

<script>
import Transactions from '../components/Transactions.vue';
import dbConnectService from '../js/dbConnectService';

export default {
  name: "summary",

  data() {
      return {
      trans: [],
      completed: 'true'
      }
  },

  mounted() {

  },

  components: {
      'trans-entry': Transactions
  },

  async created() {
    try {
      this.trans = await dbConnectService.getTransactions(
        localStorage.userId,
        this.completed,
      );
    } catch (err) {
      this.error = err.message;      
    }
  }
};
</script>

<style scoped>
.summary {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  position: fixed;
  bottom: 0px;
  width: 100%;
  overflow: auto;

}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 20%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
