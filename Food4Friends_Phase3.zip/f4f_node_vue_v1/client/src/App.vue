<template>
  <div class="body">
    <!-- this top banner will show only if signedIn is true -->
    <TopBanner v-if="signedIn" />
    <router-view></router-view>
  </div>
</template>

<script>
import TopBanner from "./components/TopBanner.vue";
export default {
  name: "app",
  components: {
    TopBanner
  },
  // the functions below will run each time App.vue is loaded
  computed: {
    signedIn: function() {
      if (this.$route.name == "signIn") {
        return false;
      } else {
        return true;
      }
    }
  },
  methods: {
    onSignIn(profileFromSignIn) {
      this.profile = profileFromSignIn
    }
  }
};
</script>

<style>
.body {
  background-image: url("./assets/background-small.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  position: fixed;
  top: 0px;
  left: 0px;
  height: 100%;
  width: 100%;
  overflow-y: auto;
}
</style>
