<template>
  <div class="ptBox">
    <h1>Pending Transactions</h1>
    <hr width="90%" />
    <div class="ptBox" v-if="transactions.length < 1">
      <h3>No transactions at the moment</h3>
    </div>
    <div class="ptBox" v-if="transactions.length > 0">
      <div class="row">
        <div class="column">
          <h3>Giver</h3>
        </div>
        <div class="column">
          <h3>Receiver</h3>
        </div>
        <div class="column">
          <h3>Transaction Description</h3>
        </div>
        <div class="column">
          <h3>Availability</h3>
        </div>
        <div class="column">
          <h3>Location</h3>
        </div>
      </div>
      <PendingTransaction
        v-for="item in transactions"
        :key="item.ORDERID"
        :orderId="item.ORDERID"
        :giver="item.GIVER"
        :receiver="item.RECEIVER"
        :transactionDescription="item.TRANSACTIONDESCRIPTION"
        :availability="item.AVAILABILITY"
        :location="item.PLACENAME"
        v-on:deleteThisItem="deleteThisItem(orderId)"
      ></PendingTransaction>
    </div>
  </div>
</template>

<script>
import PendingTransaction from "../components/PendingTransaction";
import dbConnectService from "../js/dbConnectService";

export default {
  name: "",

  data() {
    return {
      userId: String,
      transactions: [],
      completed: "false",
      error: "",
      timer: ''
    };
  },

  mounted() {
    if (localStorage.userId) {
      this.userId = localStorage.userId;
    }
  },

  components: {
    PendingTransaction
  },

  async created() {
    this.checkForPending();
    this.timer = setInterval(() => this.checkForPending(), 10000);
  },

  methods: {
    deleteThisItem(e) {
      this.transactions.splice(e, 1);
    },

    async checkForPending() {
      try {
        this.transactions = await dbConnectService.getTransactions(
          localStorage.userId,
          this.completed
        );
        if (Array.isArray(this.transactions) && this.transactions.length) {
          this.transactions.forEach(function(item) {
            if (!(item.RECEIVER === null)) {
              localStorage.notify = true;
              localStorage.recImgUrl = item.IMGURL;
              localStorage.recName = item.RECEIVER;
              localStorage.food = item.MESSAGE;
              localStorage.orderId = item.ORDERID;
            } else {
              // in scenarios where two food items are available and the first is choosen
              // this may cause the notification bell to never appear
              localStorage.notify = false;
            }
          });
        } else {
          localStorage.notify = false;
        }
      } catch (err) {
        this.error = err.message;
      }
    }
  }
};
</script>

<style scoped>
.ptBox {
  width: 100%;
  text-align: center;
  overflow: auto;
}

.row {
  width: 100%;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}

.column {
  float: left;
  width: 16%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
