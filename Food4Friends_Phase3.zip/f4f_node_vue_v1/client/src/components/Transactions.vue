<template>
  <div class="transactions">
    
    <div class="row">
      <div class="column">
        <p>{{giver}}</p>
      </div>
      <div class="column">
        <p>{{receiver}}</p>
      </div>
      <div class="column">
        <p>{{transactionDescription}}</p>
      </div>
      <!-- FUTURE DEVELOPMENT FOR RATINGS -->
      <!-- <div class="column">
        <p>{{giverRating}}</p>
      </div>
      <div class="column">
        <p>{{receiverRating}}</p>
      </div> -->
      <hr width=75% />
    </div>
    
  </div>
</template>

<script>
export default {
  name: "transaction",
  props: ['giver', 'receiver', 'transactionDescription', 'giverRating', 'receiverRating'],
  components: {},
};
</script>

<style scoped>
.transactions {
  bottom: 0px;
  width: 100%;
  height: 10%;

}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 33%;  /* change to 20% for ratings when implemented */
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}
</style>
