import Vue from 'vue';
import Router from 'vue-router';

//change the component below to test in plain page before customizing
import Test from '../components/Test.vue';
import SignInBanner from '../components/SignInBanner.vue';

Vue.use(Router);

export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: [
        {
            path: '/',
            name: 'signIn',
            component: SignInBanner
        },
        {
            path: '/home',
            name: 'home',
            component: () => import('../pages/Role.vue'),
            /* props: { webAppUser: user} */
        },
        {
            path: '/postFood',
            name: 'giver',
            component: () => import('../pages/PostFood.vue')
        },
        {
            path: '/postFood/confirmed',
            name: 'postConfirmed',
            component: () => import('../pages/Confirmation.vue')
        },
        {
            path: '/foodAvailable',
            name: 'receiver',
            component: () => import('../pages/FoodAvailable.vue')
        },
        {
            path: '/summary',
            name: 'transactionHistory',
            component: () => import('../pages/Summary.vue')
        },
        {
            path: '/test',
            name: 'test',
            component: Test
        }
    ]
})