import axios from 'axios';

const url = 'http://localhost:5000/api/';
const userUrl = 'http://localhost:5000/api/user/';

class dbConnectService {
    // Get User
    static getUser(email) {
        return new Promise(async (resolve, reject) => {
            try {

                const res = await axios.get(`${userUrl}${email}`);
                var data = res.data;
                //console.log("Got data?:  " + data);
                resolve(data);
            } catch (err) {
                //console.log("Error?");
                reject(err);
            }
        })
    }
    
    // Insert a New User with Google Profile Information
    static insertUser(userId, fName, lName, email, imgUrl) {
        return axios.post(userUrl, {
            userId,
            fName,
            lName,
            email,
            imgUrl
        })
    }
    
    // Get available food by userId
    static getTransactions(userId, completed) {
        //console.log(completed);
        return new Promise(async (resolve, reject) => {
            try {
                const res = await axios.get(`${url}transactions`, {
                    params: {
                    userId,
                    completed
                    }
                });
                console.log(completed);
                var data = res.data;
                resolve(data);
            } catch(err) {
                reject(err);
            }
        })
    }

    // Offer Food
    static offerFood(emailId, userId, duration, foodName, servings) {
        return axios.post(`${url}offerFood`, {
            emailId,
            userId,
            duration,
            foodName,
            servings
        })
    }

    // Delete Pending Offer
    static cancelPendingOffer(orderId) {
        return axios.delete(`${url}cancelDropOff/${orderId}`)
    }

    // Get available food not received and not by userId
    static getAvailableFood(userId) {
        return new Promise(async (resolve, reject) => {
            try {
                const res = await axios.get(`${url}foodAvailable/${userId}`);
                var data = res.data;
                resolve(data);
            } catch (err) {
                reject(err);                
            }
        })
    }

    // Receive Food Item
    static receiveFoodItem(orderId, userId) {
        return axios.post(`${url}receiveFood`, {
            orderId,
            userId
        })
    }
}

export default dbConnectService;