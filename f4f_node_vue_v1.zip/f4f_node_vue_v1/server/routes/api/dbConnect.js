const express = require('express');
const mysqlssh = require('mysql-ssh');

const router = express.Router();

var output;

//app users variables
var emailAddress;
emailAddress='gamerguy@dudemail.com';//info from sign in
var userName;
var userId;
//end app users variables

//post food variables
duration=60;//info from form
messagePost="i have gumbo";//info from form
//end post food variables

//variables for recieving food
var giversID;
giversID='K9AT';//get this info from when they click on recieve from someone
//

// Get App User on login
router.get('/user', (req, res) => {
    var query = "SELECT * FROM APPUSERS WHERE EMAIL = '"+emailAddress+"';";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
        //scrub username
        userName=JSON.stringify(output);
        userName = userName.slice(userName.lastIndexOf('USERNAME\\":'), userName.lastIndexOf('USERPASSWORD\\":\\'));
        userName=userName.slice(13,userName.length-5);
        //scrub userId
        userId=JSON.stringify(output);
        userId = userId.slice(userId.lastIndexOf('USERID\\":'), userId.lastIndexOf('USERNAME\\":\\'));
        userId=userId.slice(11,userId.length-5);
    }, 3000);

});

// deletes all the users entries in the queue. ALWAYS run this prior to /offerFood
router.get('/prepOffer', (req, res) => {
    var query = "DELETE FROM QUEUE WHERE GIVER = "+"'"+userId+"';";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});

// GIVER/FOOD DESCRIPTION/ OFFER FOOD PAGE
router.get('/offerFood', (req, res) => {
    var query = "INSERT INTO QUEUE(ORDERID,LOCATIONID,GIVER,RECIEVER,TIMESTART,DURATIONMINS,MESSAGE,GIVERSRATING,TAKERSRATING)"+
    "VALUES('"+emailAddress+"',1,'"+userId+"',NULL,NOW(),'"+duration+"','"+messagePost+"',NULL,NULL);";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});

//pending transactions page
//shows all the pending transactions
router.get('/pendingTransactions', (req, res) => {
    var query = "SELECT * FROM QUEUE WHERE GIVER = '"+userId+"' OR RECIEVER = '"+userId+"';";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});

//cancel giving food
router.get('/cancelDropOff', (req, res) => {
    var query = "DELETE FROM QUEUE WHERE GIVER='"+userId+"';";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});

// deletes all the users accepted food entries in the queue. ALWAYS run this prior to /recieveFood
router.get('/prepRecieve', (req, res) => {
    var query = "UPDATE QUEUE SET RECIEVER='' WHERE RECIEVER='"+userId+"';";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});

//recieve food button
router.get('/recieveFood', (req, res) => {
    var query = "UPDATE QUEUE SET RECIEVER='"+userId+"' WHERE GIVER='"+giversID+"';";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});

//cancel recieving food
router.get('/cancelRecieving', (req, res) => {
    var query = "UPDATE QUEUE SET RECIEVER='' WHERE RECIEVER='"+userId+"';";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});

//FOOD AVAILABLE PAGE
router.get('/foodAvailable', (req, res) => {
    var query = "SELECT * FROM QUEUE WHERE RECIEVER = NULL;";
    var result = connectAndQuery(query);
    setTimeout(function(){
        res.send(output);
    }, 3000);

});



function connectAndQuery(command) {
    mysqlssh.connect(
        {
            host: '74.208.82.40',
            user: 'root',
            password: 'Cg3Z68wsy1'
        },
        {
            host: 'localhost',
            user: 'root',
            password: 'kiss',
            database: 'FoodForFriends'
        }
    )
        .then(client => {
            client.query(command, function (err, results) {//command is query
                if (err) throw err;//throws error if anything in the connection goes wrong
                output = JSON.stringify(results);

                mysqlssh.close();//close sql ssh
                return output;
            })
        })
        .catch(err => {
            console.log(err)
        })
}

module.exports = router;