<template>
  <div class="role">
    <RoleChoice class="rc" />
    <PendingTransactions class="pt" />
    <!-- <h3>Here lies User: {{ webAppUser.getProfile }}</h3> -->
  </div>
</template>

<script>
import RoleChoice from "../components/RoleChoice.vue";
import PendingTransactions from "../components/PendingTransactions";
import friend from "../js/friend";

export default {
  name: "role",
  
  props: [
    'webAppUser'
  ],
  
  components: {
    RoleChoice,
    PendingTransactions
  }
};
</script>

<style scoped>
.role {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  /* font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif; */
  
}

.rc {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.pt {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  opacity: 70%;
  position: fixed;
  bottom: 0px;
  width: 100%;
  height: 30%;
}


</style>
