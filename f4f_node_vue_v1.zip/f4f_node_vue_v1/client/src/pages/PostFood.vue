<template>
  <div class="postFood">
    <FoodForm style="margin-top:5%" />
  </div>
</template>

<script>
import FoodForm from "../components/FoodForm.vue";

export default {
  name: "postFood",
  components: {
    FoodForm
  }
};
</script>

<style scoped>
.postFood {
  display: flex;
  flex-direction: column;
  justify-content: column;
  align-items: center;
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  /* font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif; */
}

</style>
