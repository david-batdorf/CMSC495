import dbConnectService from '../js/dbConnectService';

var userProfile;
var firstName = "";
var lastName = "";
var emailAddress = "";
var imageUrl = "";
var rating = 0;
var location = "";
var role = "";


class friend {
    
    // constructor used from the Google OAuth function
    constructor(profile) {
        userProfile = profile;
        console.log("Friend Info:" + userProfile);
    }

    getProfile() {
        return userProfile;
    }

    
    
}

export default friend;
