<template>
  <div class="top">
    <h1>Food 4 Friends</h1>
    
    <span class="profileImage"></span>
    <p v-on:click="navigate('transactionHistory')">
      <strong>Transaction History</strong>
    </p>
    <p v-on:click="navigate('home')">
      <strong>Home</strong>
    </p>
    <!-- This will be deleted, but it will show how the data is used from the parent App.vue file -->
    <!-- <p>{{this.$parent.profile[0].USERNAME}}</p> -->
  </div>
</template>

<script>
export default {
  name: "topbanner",
  // data dependant
  props : {
    userInfoProp: [],
  },

  data() {
    return {
      userInfoData: [],
    }
  },
  methods: {
    navigate(page) {
      this.$router.push({ name: page });
    }
  }
};
</script>

<style scoped>
.top {
  background-color: #fff;
  opacity: 70%;
  height: 115px;
  width: 100%;
  position: flex;
  padding-top: 15px;
}

.top h1 {
  text-align: left;
  font-size: 40px;
  margin-left: 40px;
  display: inline-table;
  vertical-align: middle;
}

.top p {
  font-size: 20px;
  color: rgb(155, 155, 155);
  float: right;
  padding-top: 20px;
  padding-right: 50px;
}

.top p:hover {
  cursor: pointer;
}

.profileImage {
  /* Use Google Profile image address here */
  background: url("https://lh3.googleusercontent.com/a-/AAuE7mAW7V-nmoX_fED1m1TJnmFLqmPm9wP79V1CkEEBue4=s96-cc-rg");
  background-size: 75px, 75px;
  background-repeat: no-repeat;
  background-position-y: 50%;
  padding-right: 10px;
  float: right;
  vertical-align: middle;
  padding-top: 30px;
  width: 75px;
  height: 75px;
}
</style>