<template>
  <div class="signin">
    <h1>Food 4 Friends</h1>
    <hr width="60%" />
    <img src="../assets/soup.jpg" />
    <p>A new way to give and receive food with people in your neighborhood.</p>

    <!-- BELOW IS TEST BUTTON FOR TESTING PURPOSES ONLY -->
    <div class="testButton" v-on:click="navigate()">
      <span class="icon"></span>
      <span class="buttonText">Sign In with Google</span>
    </div>

    <!-- BELOW IS GOOGLE OAUTH2 BUTTON CONNECTED TO API -->
    <!-- <g-signin-button :params="googleSignInParams" @success="onSignInSuccess" @error="onSignInError">
      <span class="icon"></span>
      <span class="buttonText">Sign In with Google</span>
    </g-signin-button> -->
  </div>
</template>

<script>
import dbConnectService from '../js/dbConnectService';
import friend from '../js/friend';

export default {
  name: "signinbanner",
  data() {
    return {
      // data associated with component
      userInfo: Object,
      error: '',
      friend: [],

      /**
       * The Auth2 parameters, as seen on
       * https://developers.google.com/identity/sign-in/web/reference#gapiauth2initparams.
       * As the very least, a valid client_id must present.
       * @type {Object}
       */
      googleSignInParams: {
        client_id:
          "379813336107-0pa4h0hc6mjtu50rtegj7t1qtbsofmef.apps.googleusercontent.com"
      }
    };
  },
  methods: {
    /* navigate() {
      this.friend = new friend("Print This");
    }, */


    async navigate() {
      var info;
      try {
        // make a call to the backend using dbConnectService to fill data
        info = await dbConnectService.getUser();
        this.friend = new friend(info);
        this.$emit('userData', info);
      } catch (err) {
        this.error = err.message;
        console.log(this.error);
      }
      this.$router.push({ name: "home", params: { webAppUser: this.friend } });
    },
    onSignInSuccess(googleUser) {
      // `googleUser` is the GoogleUser object that represents the just-signed-in user.
      // See https://developers.google.com/identity/sign-in/web/reference#users
      this.userInfo = googleUser.getBasicProfile(); // etc etc
      this.friend = new friend(userInfo);
    },
    onSignInError(error) {
      // prevent user to proceeding further in app
      return error; // placed to prevent no-unused-var error from eslint
    }
  }
  };
</script>

<style scoped>
.signin {
  height: 500px;
  width: 300px;
  background-color: #fff;
  text-align: center;
  border-radius: 35px;
  padding: 20px 20px 20px 20px;
  margin: 200px 200px 0px;
}
.testButton {
  display: table;
  padding: 4px 8px;
  border-radius: 50px;
  background-color: #4caf50;
  color: #fff;
  align-content: center;
  width: 280px;
  height: 80px;
}
.testButton:hover {
  cursor: pointer;
}
.g-signin-button {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 50px;
  background-color: #4caf50;
  color: #fff;
  vertical-align: middle;
  width: 280px;
  height: 80px;
}
.g-signin-button:hover {
  cursor: pointer;
}
span.icon {
  display: inline-block;
  margin-top: 17px;
  margin-left: 7px;
  width: 42px;
  height: 42px;
  background: url("../assets/g-normal.png") no-repeat;
  background-color: #fff;
}
span.buttonText {
  display: table-cell;
  vertical-align: middle;
  padding-left: 35px;
  padding-right: 35px;
  font-size: 15px;
  font-weight: bold;
  font-family: "Roboto", sans-serif;
}


h3 {
  font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
  font-size: 30px;
}

p {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 20px;
  padding-bottom: 20px;
}

/**This can be deleted once button is added */
#G_SignIn {
  color: green;
}
</style>