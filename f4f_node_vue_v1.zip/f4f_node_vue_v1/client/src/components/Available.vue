<template>
  <div class="transactions">
    <div class="row">
      <div class="column">
        <p>{{giver}}</p>
      </div>
      <div class="column">
        <p>{{foodType}}</p>
      </div>
      <div class="column">
        <p>{{servings}}</p>
      </div>
      <div class="column">
        <p>{{availability}}</p>
      </div>
      <div class="column">
        <p>{{location}}</p>
      </div>
      <div class="column">
        <div class="requestButton"> <!-- will need to add click function -->
          <p>Request Meet Up</p>
        </div>
      </div>
      <hr width="75%" />
    </div>
  </div>
</template>

<script>
export default {
  name: "transaction",
  props: ["giver", "foodType", "servings", "availability", "location"],
  components: {}
};
</script>

<style scoped>
.transactions {
  /* display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #fff;
  position: fixed; */
  bottom: 0px;
  width: 100%;
  height: 550px;
  padding: 30px 30px;
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 16%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}

.requestButton {
  background-color: #4caf50;
  text-align: center;
  display: inline-block;
  vertical-align: middle;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.requestButton:hover {
  cursor: pointer;
}

.requestButton p {
  color: #fff;
  font-size: 12px;
  padding-top: 4%;
}
</style>
