<template>
  <div class="ptBox">
    <h1>Pending Transactions</h1>
    <hr width="90%" />
    <div class="ptBox" v-if="transactions.length < 1">
      <h3>No transactions at the moment</h3>
    </div>
    <div class="ptBox" v-if="transactions.length > 0">
      <div class="row">
        <div class="column">
          <h3>Giver</h3>
        </div>
        <div class="column">
          <h3>Receiver</h3>
        </div>
        <div class="column">
          <h3>Transaction Description</h3>
        </div>
        <div class="column">
          <h3>Availability</h3>
        </div>
        <div class="column">
          <h3>Location</h3>
        </div>
      </div>
      <div class="row">
        <div class="column">
          <p>{{transactions[0]}}</p>
        </div>
        <div class="column">
          <p>{{transactions[1]}}</p>
        </div>
        <div class="column">
          <p>{{transactions[2]}}</p>
        </div>
        <div class="column">
          <p>{{transactions[3]}}</p>
        </div>
        <div class="column">
          <p>{{transactions[4]}}</p>
        </div>
        <div class="column">
            <div class="cancelButton"> <!-- will need to add click function -->
          <p>Cancel</p>
        </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "",

  data() {
    return {
      // edit this value to alter the component
      //transactions: []
      /* transactions:[
        {
          giver: "David Markowski",
          receiver: "Pending",
          transactionDescription: "1 Serving of Irish Beef and Guinness Stew",
          availability: "2 hours",
          location: "UMUC"
        }
      ] */
      transactions: ["David Markowski","Pending","1 Serving of Irish Beef and Guiness Stew", "2 hours", "UMUC"]
    };
  },

  components: {}
};
</script>

<style scoped>
.ptBox {
  width: 100%;
}

.row {
  width: 100%;
}

.column {
  float: left;
  width: 16%;
  text-align: center;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  padding-bottom: 1px;
}

.cancelButton {
  background-color: #ff0000;
  text-align: center;
  display: inline-block;
  vertical-align: middle;
  width: 220px;
  height: 60px;
  border-radius: 10px;
}

.cancelButton:hover {
  cursor: pointer;
}

.cancelButton p {
  color: #000;
  font-size: 12px;
  padding-top: 4%;
}
</style>
